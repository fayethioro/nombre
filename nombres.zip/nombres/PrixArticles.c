#include <stdio.h>
int main()
{
    int  prix,somme = 0;
           
     printf("Donner le prix: ");
     scanf("%d", &prix);  

    /* controle de saisie*/    
    do 
    {
            while(prix<0)
        {
            printf("ATTENTION !!! y'a une ou des erreurs \n");
            printf("l'entier doit etre strictement positive\n");
            printf("Donner un autre prix : ");
            scanf("%d", &prix);
        }
            somme = somme + prix;
            printf("Entrez le prix de l'article suivante :");
            scanf("%d",&prix); 
        
    } while (prix != 0);
            
    printf("la somme des articles est %d\n",somme);
    return 0;
}
