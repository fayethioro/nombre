#include <stdio.h>
int main(int argc, char const *argv[])
{
    int n,premier = 0;
  
           
    printf("Entrez un nombre entier :");
    scanf("%d",&n);
    
     /* controle de saisie*/
    do
    {
            if(n<=0)
            {
                printf("ATTENTION !!! y'a une ou des erreurs \n");
                printf("le nombre saisie  doit etre strictement positive\n");
                printf("Entrez un nombre entier :");
                scanf("%d",&n); 
            }
    } while (n<0);

     for (int i = 1; i <=n; i++)
     {
       if (n % i == 0)
       {
         premier++;
       }
     }
     if (premier == 2)
        printf("le nombre %d est premier\n",n);
    
    else
        printf("le nombre %d n'est n\n",n);
     
    return 0 ;
}