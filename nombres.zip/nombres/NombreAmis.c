#include <stdio.h>
int main()
{
    int N, M, Ndiv = 0, Mdiv = 0 ;
    int i , j;
            
    printf("Entrez deux nombres entiers :");
    scanf("%d%d",&N,&M);

    /* controle de saisie*/
    do
    {
            if(N<=0 || M<=0)
            {
                printf("ATTENTION !!! y'a une ou des erreurs \n");
                printf("les nombres saisie  doivent etre strictement positive\n");
                printf("Entrez deux nombres entier :");
                scanf("%d %d",&N,&M);
            }

    } while (N<=0 || M<=0);

    for ( i = 2; i <N; i++)
    {        
        if (N % i == 0)
        { 
            Ndiv += i; 
        }
    }
    printf("\nla somme des  diviseur de %d est %d\n",N,Ndiv); 
    for (j = 2; j <M; j++)
    {
        if (M % j == 0)
        {
            Mdiv += j; 
        } 
    }
    printf("\nLa somme  des  diviseur de %d est %d", M,Mdiv); 
    if (Ndiv == M && Mdiv == N)
        printf("\n Donc %d et %d sont des nombres Amis\n",N,M);
    
    else
        printf(" \n Donc %d et %d ne sont pas des nombres Amis\n",N,M);
    
return 0 ;

}