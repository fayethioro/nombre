#include <stdio.h>
int main()
{
    int a, b ,c, d ;
 
            
    printf("Entrez deux nombres entiers :");
    scanf("%d %d",&a,&b);

    /* controle de saisie*/
    do
    {
            if(a<=0 || b<=0)
            {
                printf("ATTENTION !!! y'a une ou des erreurs \n");
                printf("les nombres saisie  doivent etre strictement positive\n");
                printf("Entrez deux nombres entier :");
                scanf("%d %d",&a,&b);
            }

    } while (a<=0 || b<=0);

    c = a ;
    d = b ;

    while ( a != b)
    {
      if (a > b )
        b = d + b ;
      else
        a = c + a ;
    }

    printf("la PPCM de %d et %d est %d\n",c,d,b);

return 0;
}