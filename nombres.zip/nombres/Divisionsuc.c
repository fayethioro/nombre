#include <stdio.h>
int main()
{
    int a, b , d,cpt=0;
  
            
    printf("Entrez deux nombres entiers :");
    scanf("%d %d",&a,&b);

    /* controle de saisie*/
    do
    {
            if(a<=0 || b<=0)
            {
                printf("ATTENTION !!! y'a une ou des erreurs \n");
                printf("les nombres saisie  doivent etre strictement positive\n");
                printf("Entrez deux nombres entier :");
                scanf("%d %d",&a,&b);
            }
    } while (a<=0 || b<=0);

    d=a;

    while ( a>= b)
    {
       a = a - b ;
       cpt ++;
    }
    printf("la division de %d et %d est %d\n",d,b,cpt);

return 0;
}