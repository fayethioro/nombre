#include <stdio.h>

int main(int argc, char const *argv[])
{
    int n,cpt = 0 ,p, premier = 0;

    
    /* controle de saisie*/ 
    do
    {   
        printf("Donner un entier: ");
        scanf("%d", &n);
        while(n<0)
        {
            printf("ATTENTION !!! y'a une ou des erreurs \n");
            printf("l'entier doit etre strictement positive\n");
            printf("Donner un  autre entier : ");
            scanf("%d", &n);
        }
        cpt++;
   } while (n != 0);
   printf("le nombre d'element est %d\n",cpt-1);
   printf("les nombre premier sont :\n");
   for (int i = 1; i <= cpt-1; i++)
            {
                premier = 0 ;
                for (int j = 1; j<=i; j++)
                {
                    if (i % j == 0)
                    {
                        premier++;
                    }
                }
            if (premier == 2)
                {
                     printf("%d ",i);
                     p++;
                }
            }
        printf("\nle nombre de nombre premier est %d\n",p);
    return 0;
}
