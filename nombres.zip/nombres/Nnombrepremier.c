#include <stdio.h>
int main(int argc, char const *argv[])
{
    int n,premier ;
  
           
   
    printf("Entrez un nombre entier :");
    scanf("%d",&n);
    
     /* controle de saisie*/
    
    do{
            if(n<=0)
            {
                printf("ATTENTION !!! y'a une ou des erreurs \n");
                printf("le nombre saisie  doit etre strictement positive\n");
                printf("Entrez un nombre entier :");
                scanf("%d",&n); 
            }
    } while (n<0);
    for (int i = 1; i <= n; i++)
    {
        premier = 0 ;
        for (int j = 1; j<=i; j++)
     {
       if (i % j == 0)
       {
         premier++;
       }
     }
     if (premier == 2)
        printf("le nombre %d est premier\n",i);
    
    else
        printf("le nombre %d n'est n\n",i);
    }
      
    return 0 ;
}