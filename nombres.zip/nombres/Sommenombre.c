#include <stdio.h>
int main()
{
    int n,somme = 0;
  
            
    printf("Entrez un nombre entier :");
    scanf("%d",&n);
    /* controle de saisie*/
    
    do
    {
            if(n<=0)
            {
                printf("ATTENTION !!! y'a une ou des erreurs \n");
                printf("le nombre saisie  doit etre strictement positive\n");
                printf("Entrez un nombre entier :");
                scanf("%d",&n); 
            }
    } while (n<0);

    for (int i = 1; i <= n ; i++)
    {
        
          somme+=i;
    }
    printf("somme des %d nonmbres est: %d\n",n,somme);
return 0;
}