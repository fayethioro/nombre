#include <stdio.h>
int main()
{
    int n,max, i_max ;

  
            
    printf("Entrez un nombre entier :");
    scanf("%d",&n);

    /* controle de saisie*/

    do
    {
            if(n<=0)
            {
                printf("ATTENTION !!! y'a une ou des erreurs \n");
                printf("le nombre saisie  doit etre strictement positive\n");
                printf("Entrez un nombre entier :");
                scanf("%d",&n); 
            }
    } while (n<0);
     
     max = n ;
     i_max = 1;

    for (int i = 2; i < 10 ; i++)
    {

        printf("Entrez un nombre N° %d :",i);
        scanf("%d",&n);

        if (n > max)
        {
           i_max = i;
           max = n ;
        }  
    }
    
    printf("le plus grand des nombres est %d \n",max);
    printf("Sa position est %d \n",i_max);
        
    return 0;

    }