#include <stdio.h>
int main(int argc, char const *argv[])
{
    int n,somme = 0;
  
           
    printf("Entrez un nombre entier :");
    scanf("%d",&n);
            /* controle de saisie*/
    do
    {
            if(n<=0)
            {
                printf("ATTENTION !!! y'a une ou des erreurs \n");
                printf("le nombre saisie  doit etre strictement positive\n");
                printf("Entrez un nombre entier :");
                scanf("%d",&n); 
            }
    } while (n<0);

    for (int i = 0; i < n ; i++)
    {
        if(n % 2 == 0)
          somme++;
    }
    if (n == somme)
        printf("le nombre %d est parfait\n",n);
    
    else
        printf("le nombre %d n'est pas parfait\n",n);
        
    return 0;
}
