#include <stdio.h>
int main()
{
    int n,val ,t = 0;
  do
    {
            /* controle de saisie*/
            printf("Entrez un nombre le nombnre a deviner :");
            scanf("%d",&n);
            if(n<=0)
            {
                printf("ATTENTION !!! y'a une  erreur\n");
                printf("le nombre a deviner  doit etre strictement positive\n");
                printf("Entrez un nombre le nombre a deviner :");
                scanf("%d",&n); 
            }
    } while (n<0);

    do
    {
            
      printf("Entrez votre nombre :");
      scanf("%d",&val);

        /* controle de saisie*/
        do
        {
           
                if(val<=0)
                {
                    printf("ATTENTION !!! y'a une ou des erreurs \n");
                    printf("votre nombre doit etre positive\n");
                    printf("Entrez votre nombre:");
                    scanf("%d",&val); 
                }
        }while (val<0);
        
                if (n  > val)
                {
                    printf("Votre nombre doit etre plus grand que %d \n",val);
                }
                else
                if(n < val)
                {
                printf("Votre nombre doit etre plus petit que %d \n",val);
                }  

                t++; 

    } while (val != n);
    
    printf("Bravo vous avez gagne et votre score est %d\n",t);

    return 0 ;
}